const { expect } = require('@playwright/test');

class BoardPage {
  constructor(page) {
    this.page = page;
  }

  async navigateToProject(projectName) {
    await this.page.click(`text=${projectName}`);
  }

  // Verifies the task name is under the correct Column name (Ex: To Do || In Progress)
  async verifyColumnandTask(columnName, taskName) {
     const column = this.page.locator('div.flex.flex-col.w-80.bg-gray-50.rounded-lg.p-4', {has: this.page.locator('h2', { hasText: columnName })});

  await expect(column).toHaveCount(1);  //ensures it grabs the unique column    
  await expect(column.locator(`h2`, { hasText: columnName })).toBeVisible(); //verifes name of column matches expected name

 
  const task = column.locator('h3', { hasText: taskName }); //verifies it finds the task name within the column
  await expect(task).toHaveCount(1);    // ensure exactly one unique task name
  await expect(task).toBeVisible(); //checks if task is visible on screen to user
  }


  async verifyTags(taskName, tags) {

   const taskCard = this.page.locator('div.bg-white.p-4.rounded-lg.shadow-sm.border', { has: this.page.locator('h3', { hasText: taskName })}); //finds the title of the task
   await expect(taskCard).toHaveCount(1); //ensures no duplicates of task cards

   const getTags = await taskCard.locator('div.flex.flex-wrap span').allTextContents(); //gets all tags
   const trimmedTags = getTags.map(t => t.trim()); //separates all tags into array

   expect(trimmedTags.sort()).toEqual(tags.sort()); //compares grabbed tags to expected tags of json

    
  }
}

module.exports = { BoardPage };