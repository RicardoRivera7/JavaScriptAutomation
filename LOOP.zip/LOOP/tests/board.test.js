const { test } = require('@playwright/test');
const { LoginPage } = require('../pages/login');
const { BoardPage } = require('../pages/boardpage');
const testData = require('../testdata/boardtestdata.json');

test.describe('Data Driven Board Tests - JavaScript', () => {

  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('admin', 'password123');
  });

  testData.forEach((scenario) => {

    test(`Validate task: ${scenario.task}`, async ({ page }) => {

      const boardPage = new BoardPage(page);

      await boardPage.navigateToProject(scenario.project);
      await boardPage.verifyColumnandTask(scenario.column, scenario.task);
      await boardPage.verifyTags(scenario.task,scenario.tags);

    });

  });

});